# Lugard-Dev Portfolio

A responsive, dark-themed starter portfolio for an aspiring full-stack developer. Built as a simple static website so it can be opened locally and deployed without a build step.

## Preview locally
1. Extract the ZIP file.
2. Open the `index.html` file in Chrome, Edge, Firefox, or another browser.

## Personalize before publishing
- Replace the placeholder email `hello@lugard.dev` with your real email.
- Add your real GitHub, LinkedIn, and other professional links.
- Update the skills as you learn them.
- The three project cards are explicitly labeled as project ideas. Build them before presenting them as completed projects, then add demo and source-code links.
- Do not claim client work, years of experience, or skills you don't yet have.

## Publish free with GitHub + Vercel
1. Create or sign in to a GitHub account at https://github.com/
2. Create a new repository, e.g. `lugard-dev-portfolio`.
3. Upload `index.html` (and this README if you like) to the repository.
4. Sign in to https://vercel.com/ using GitHub.
5. Choose **Add New → Project**, import the repository, and deploy. A static `index.html` site does not need a build command.
6. Vercel will provide a live URL. You can later connect a custom domain if you want.

Alternative: use any static hosting service that supports HTML files.

## Next learning steps
1. Learn HTML and CSS by editing this page.
2. Learn JavaScript by adding small interactive features.
3. Build the task manager project.
4. Learn React, then backend APIs and databases.
5. Replace project ideas with real demos and GitHub repositories.
